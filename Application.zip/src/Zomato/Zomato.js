import React, { useState } from "react";
import Searchbar from "../Searchbar/searchbar";

const fetchData = async (instrumentId) => {
  const response = await fetch(`https://localhost:7182/Data?instrumentToken=${instrumentId}`);
  const data = await response.json();
  return data;
};


function Zomato() {
  const [data, setData] = useState({ zomatoCandles: [], niftyCandles: [] });

  // Ger stock and nifty Data
  const fetchDataAndSetData = async (instrumentId) => {
    const data = await fetchData(instrumentId);
    data.zomatoCandles.sort((a, b) => {
      return new Date(b.timestamp) - new Date(a.timestamp);
    });
    data.niftyCandles.sort((a, b) => {
      return new Date(b.timestamp) - new Date(a.timestamp);
    });
    setData(data);
  };


  const getRowBackgroundColor = (candle) => {
    if (candle.timestamp.includes("9:30")) {
      const newZomatoCandles = getElementsAfterIndex(data.zomatoCandles, data.zomatoCandles.findIndex(obj => obj.timestamp === candle.timestamp));
      const newNiftyCandles = getElementsAfterIndex(data.niftyCandles, data.niftyCandles.findIndex(obj => obj.timestamp === candle.timestamp));
      const checkCloseZomatoBuy = checkCloseValuesBuy(newZomatoCandles);
      const checkCloseNiftyBuy = checkCloseValuesBuy(newNiftyCandles);
      const checkCloseZomatoSell = checkCloseValuesSell(newZomatoCandles);
      const checkCloseNiftySell = checkCloseValuesSell(newNiftyCandles);
      debugger;
      if (checkCloseZomatoBuy && checkCloseNiftyBuy) {
        return "green"
      }
      else if (checkCloseZomatoSell && checkCloseNiftySell) {
        return "red"
      }

    }
  }

  function getElementsAfterIndex(arr, index) {
    const filteredArray = arr.slice(index, index + 5);
    filteredArray.splice(4, filteredArray.length - 4);
    return filteredArray;
  }

  function checkCloseValuesBuy(data) {
    debugger;
    for (let i = 0; i < data.length - 1; i++) {
      if (data[i].close <= data[i + 1].close) {
        return false;
      }
    }
    return true;
  }

  function checkCloseValuesSell(data) {
    for (let i = data.length - 1; i > 0; i--) {
      if (data[i].close <= data[i - 1].close) {
        return false;
      }
    }
    return true;
  }

  return (
    <div>
      <Searchbar
        getData={fetchDataAndSetData}
      />
      <table className="candles-table">
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Open</th>
            <th>High</th>
            <th>Low</th>
            <th>Close</th>
            <th>Volume</th>
          </tr>
        </thead>
        <tbody>
          {data.zomatoCandles.map((candle) => {
            const date = new Date(candle.timestamp);
            const formattedDate = `${date.getFullYear()}-${date.toLocaleString("en-US", { month: "long" })}-${date.getDate().toString().padStart(2, "0")} ${date.getHours().toString().padStart(2, "0")}:${date.getMinutes().toString().padStart(2, "0")}`;

            return (
              <tr key={candle.timestamp} style={{ backgroundColor: getRowBackgroundColor(candle) }}>
                <td>{formattedDate}</td>
                <td>{candle.open}</td>
                <td>{candle.high}</td>
                <td>{candle.low}</td>
                <td>{candle.close}</td>
                <td>{candle.volume}</td>
              </tr>
            );
          })}

        </tbody>
      </table>
    </div>

  );
}

export default Zomato;
