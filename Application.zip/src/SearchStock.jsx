import React, { useState } from "react";
import JoditEditor from "jodit-react";
import "jodit/build/jodit.min.css";

function SearchStock() {
  const [content, setContent] = useState("");

  // Define the configuration options for the Jodit editor
  const config = {
    readonly: false, // all options from https://xdsoft.net/jodit/doc/
    height: 300, // set editor's height
  };

  // Update the content state with the new value from the editor
  const handleEditorChange = (newContent) => {
    setContent(newContent);
  };

  return (
    <div>
      <JoditEditor
        value={content}
        config={config}
        tabIndex={1} // tabIndex of textarea
        onBlur={handleEditorChange}
        onChange={handleEditorChange}
      />
    </div>
  );
}

export default SearchStock;
