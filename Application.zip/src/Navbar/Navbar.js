import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import './Navbar.css';

const isActive = (location, href) => location.pathname === href;

const Navbar = () => {
  const location = useLocation();
  return (
    <nav className="navbar">
      <NavLink to="/" className={isActive(location, "/") ? "nav-link active" : "nav-link"} end>
        Home
      </NavLink>
      <NavLink
        to="/Zomato"
        className={isActive(location, "/Zomato") ? "nav-link active" : "nav-link"}
      >
        Morning Breakout
      </NavLink>
      <NavLink
        to="/SearchStock"
        className={isActive(location, "/SearchStock") ? "nav-link active" : "nav-link"}
      >
        Search Stock
      </NavLink>
    </nav>
  );
};

export default Navbar;