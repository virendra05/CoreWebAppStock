import React, { useState, useEffect } from "react";

const fetchData = async () => {
  const response = await fetch(`https://localhost:7182/Data/GetAllStocks`);
  const data = await response.json();
  return data;
};

function Home() {
  const [rowData, setData] = useState([]);

  // Ger stock and nifty Data
  const fetchDataAndSetData = async () => {
    const rowData = [];
    console.log(new Date());
    const data = await fetchData();
    data.forEach((element) => {
      element.candles.sort((a, b) => {
        return new Date(b.timestamp) - new Date(a.timestamp);
      });
    });
    data.forEach((element, index) => {
      if(element.candles.length<6){
        return;
      }
      const colorValue = isBreakout(
        element.candles[6],
        element.candles[5],
        element.candles[4],
        element.candles[3],
        element.candles[2],
        element.candles[1],
        element.candles[0]
      );
      if (colorValue === "green" || colorValue === "red") {
        sendMail(
          element.name,
          element.candles[1].timestamp,
          colorValue === "red" ? "Sell" : "Buy"
        );
      }
      rowData.push({
        name: element.name,
        timestamp: element.candles[0].timestamp,
        open: element.candles[0].open,
        high: element.candles[0].high,
        low: element.candles[0].low,
        close: element.candles[0].close,
        volume: element.candles[0].volume,
        color: colorValue,
      });
    });
    setData(rowData);
  };

  useEffect(() => {
    fetchDataAndSetData();
    const times = [
      "10:44am",
      "10:59am",
      "11:14am",
      "11:29am",
      "11:44am",
      "11:59am",
      "12:14pm",
      "12:30pm",
      "12:44pm",
      "12:59pm",
      "01:14pm",
      "01:29pm",
      "01:44pm",
      "01:59pm",
      "02:14pm",
      "02:29pm",
      "02:44pm",
      "02:59pm",
      "03:14pm",
      "03:31pm",
      "09:56pm",
    ];

    const timeToMilliseconds = (timeString) => {
      const now = new Date();
      const [time, meridiem] = timeString.split(/([ap]m)/);
      const [hour, minute] = time.split(":").map(Number);
      const adjustedHour = meridiem === "pm" && hour !== 12 ? hour + 12 : hour;
      const date = new Date(now);
      date.setHours(adjustedHour, minute, 0, 0);
      return date.getTime();
    };

    const timers = times.map((time) => {
      const ms = timeToMilliseconds(time);
      const now = new Date().getTime();
      const delay = ms - now > 0 ? ms - now : ms - now + 24 * 60 * 60 * 1000;
      return setTimeout(() => fetchDataAndSetData(), delay);
    });

    return () => {
      timers.forEach((timer) => clearTimeout(timer));
    };
  }, []);

  const sendMail = async (name, time, signal) => {
    const date = new Date(time);
    const formattedDate = `${date.getFullYear()}-${date.toLocaleString(
      "en-US",
      { month: "long" }
    )}-${date.getDate().toString().padStart(2, "0")} ${date
      .getHours()
      .toString()
      .padStart(2, "0")}:${date.getMinutes().toString().padStart(2, "0")}`;

    const body = name + " " + formattedDate + " " + signal;
    console.log(body);
    await fetch(`https://localhost:7182/Data/sendMail?body=` + body);
  };

  const isBreakout = (
    candle1,
    candle2,
    candle3,
    candle4,
    candle5,
    candle6,
    candle7
  ) => {
    //cacluation based on open
    const candlesOpen = JSON.parse(
      JSON.stringify([candle1, candle2, candle3, candle4])
    );
    const candlesClose = JSON.parse(
      JSON.stringify([candle1, candle2, candle3, candle4])
    );
    candlesOpen.forEach((element) => {
      if (element.close < element.open) {
        const open = element.open;
        const close = element.close;
        element.close = open;
        element.open = close;
      }
    });

    candlesClose.forEach((element) => {
      if (element.open > element.close) {
        const open = element.open;
        const close = element.close;
        element.close = open;
        element.open = close;
      }
    });

    const tolerance = 0.01;
    const areOpenPricesSame = checkOpenPriceTolerance(candlesOpen, tolerance);
    const areClosePricesSame = checkClosePriceTolerance(
      candlesClose,
      tolerance
    );
    if (areOpenPricesSame) {
      //red candle condition for 5th and 6th candle
      if (candle5.open > candle5.close && candle5.close < candle4.close) {
        if (candle6.close < candle5.close) {
          if (candle7.close < candle6.close) {
            return "red";
          }
        }
      }
      //green candle condition for 5th and 6th candle
      if (candle5.open < candle5.close && candle5.close > candle4.close) {
        if (candle6.close > candle5.close) {
          if (candle7.close > candle6.close) {
            return "green";
          }
        }
      }
    } else if (areClosePricesSame) {
      //red candle condition for 5th and 6th candle
      if (candle5.open > candle5.close && candle5.close < candle4.close) {
        if (candle6.close < candle5.close) {
          if (candle7.close < candle6.close) {
            return "red";
          }
        }
      }
      //green candle condition for 5th and 6th candle
      if (candle5.open < candle5.close && candle5.close > candle4.close) {
        if (candle6.close > candle5.close) {
          if (candle7.close > candle6.close) {
            return "green";
          }
        }
      }
    }
    return "";
  };

  function checkOpenPriceTolerance(candles, tolerance) {
    const firstOpenPrice = candles[0].open;

    return candles.every((candle) => {
      const difference = Math.abs(candle.open - firstOpenPrice);
      const percentageDifference = (difference / firstOpenPrice) * 100;
      return percentageDifference <= tolerance;
    });
  }

  function checkClosePriceTolerance(candles, tolerance) {
    const firstClosePrice = candles[0].close;
    return candles.every((candle) => {
      const difference = Math.abs(candle.close - firstClosePrice);
      const percentageDifference = (difference / firstClosePrice) * 100;
      return percentageDifference <= tolerance;
    });
  }

  return (
    <div>
      <table className="candles-table">
        <thead>
          <tr>
            <th>Stock Name</th>
            <th>Timestamp</th>
            <th>Open</th>
            <th>High</th>
            <th>Low</th>
            <th>Close</th>
            <th>Volume</th>
          </tr>
        </thead>
        <tbody>
          {rowData.map((element) => {
            const date = new Date(element.timestamp);
            const formattedDate = `${date.getFullYear()}-${date.toLocaleString(
              "en-US",
              { month: "long" }
            )}-${date.getDate().toString().padStart(2, "0")} ${date
              .getHours()
              .toString()
              .padStart(2, "0")}:${date
              .getMinutes()
              .toString()
              .padStart(2, "0")}`;

            return (
              <tr key={element.name} style={{ backgroundColor: element.color }}>
                <td>{element.name}</td>
                <td>{formattedDate}</td>
                <td>{element.open}</td>
                <td>{element.high}</td>
                <td>{element.low}</td>
                <td>{element.close}</td>
                <td>{element.volume}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default Home;
