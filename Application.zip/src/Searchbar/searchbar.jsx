import React, { useState } from 'react';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { TextField, Select, MenuItem, Button, Box, Grid,  FormControl, InputLabel, OutlinedInput } from '@material-ui/core';

function Searchbar(props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [timeInterval, setTimeInterval] = useState('');



  const fetchData = async () => {
    if (selectedItem) {
      console.clear();
      console.log(selectedItem);
      props.getData(selectedItem.instrumentToken, timeInterval);
      setQuery('');
      setSelectedItem(null);
    }
  };

  const handleInputChange = async (event, value) => {
    setQuery(value);
    if (value.length >= 3) {
      const response = await fetch(`https://localhost:7182/Data/GetInstrumentData?prefix=${value}`);
      const data = await response.json();
      setResults(data);
    } else {
      setResults([]);
    }
  };

  const handleChange = (event) => {
    setTimeInterval(event.target.value);
  };

  return (
    <Box>
      <Grid container spacing={2} alignItems="center">
        <Grid item xs>
          <Autocomplete
            options={results}
            getOptionLabel={(option) => `${option.segment}: ${option.instrumentType}: ${option.tradingSymbol} ${option.expiry ? "Expiry: " + option.expiry : ''}`}
            onInputChange={handleInputChange}
            onChange={(event, value) => setSelectedItem(value)}
            renderInput={(params) => <TextField {...params} label="Search..." variant="outlined" fullWidth />}
          />
        </Grid>
        <Grid item xs>
          <FormControl fullWidth variant="outlined">
            <InputLabel id="time-interval-label">Time Interval</InputLabel>
            <Select
              labelId="time-interval-label"
              id="time-interval-dropdown"
              value={timeInterval}
              onChange={handleChange}
              label="Time Interval"
              input={<OutlinedInput label="Time Interval" />}
            >
              <MenuItem value="1minute">1 Minute</MenuItem>
              <MenuItem value="5minute">5 Minutes</MenuItem>
              <MenuItem value="15minute">15 Minutes</MenuItem>
              <MenuItem value="30minute">30 Minutes</MenuItem>
              <MenuItem value="1hour">1 Hour</MenuItem>
              <MenuItem value="1day">1 Day</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item>
          <Button variant="contained" color="primary" onClick={fetchData}>
            Search
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
}

export default Searchbar;
