import React, { useState } from "react";
import SearchStock from "../SearchStock/searchStock";

const fetchData = async (instrumentId, timeInterval) => {
  const response = await fetch(
    `https://localhost:7182/Data?instrumentToken=${instrumentId}&interval=${timeInterval}`
  );
  const data = await response.json();
  return data;
};

function Home() {
  const [data, setData] = useState({ zomatoCandles: [], niftyCandles: [] });

  // Ger stock and nifty Data
  const fetchDataAndSetData = async (instrumentId, timeInterval) => {
    const data = await fetchData(instrumentId, timeInterval);
    data.zomatoCandles.forEach((candle, index) => {
      candle.color = "";
    });

    data.zomatoCandles.sort((a, b) => {
      return new Date(b.timestamp) - new Date(a.timestamp);
    });

    data.zomatoCandles.forEach((candle, index) => {
      if (candle.timestamp === "2023-03-15T14:45:00+05:30") {
        debugger;
      }

      if (index <= data.zomatoCandles.length - 6) {
        data.zomatoCandles[index].color = isBreakout(
          data.zomatoCandles[index + 5],
          data.zomatoCandles[index + 4],
          data.zomatoCandles[index + 3],
          data.zomatoCandles[index + 2],
          data.zomatoCandles[index + 1],
          candle
        );
      }
    });
    setData(data);
  };

  const isBreakout = (candle1, candle2, candle3, candle4, candle5, candle6) => {
    //cacluation based on open
    const candlesOpen = JSON.parse(
      JSON.stringify([candle1, candle2, candle3, candle4])
    );
    const candlesClose = JSON.parse(
      JSON.stringify([candle1, candle2, candle3, candle4])
    );
    candlesOpen.forEach((element) => {
      if (element.close < element.open) {
        const open = element.open;
        const close = element.close;
        element.close = open;
        element.open = close;
      }
    });

    candlesClose.forEach((element) => {
      if (element.open > element.close) {
        const open = element.open;
        const close = element.close;
        element.close = open;
        element.open = close;
      }
    });

    const tolerance = 0.01;
    const areOpenPricesSame = checkOpenPriceTolerance(candlesOpen, tolerance);
    const areClosePricesSame = checkClosePriceTolerance(
      candlesClose,
      tolerance
    );
    if (areOpenPricesSame) {
      //red candle condition for 5th and 6th candle
      if (candle5.open > candle5.close && candle5.close < candle4.close) {
        if (candle6.close < candle5.close) {
          return "red";
        }
      }
      //green candle condition for 5th and 6th candle
      if (candle5.open < candle5.close && candle5.close > candle4.close) {
        if (candle6.close > candle5.close) {
          return "green";
        }
      }
    } else if (areClosePricesSame) {
      //red candle condition for 5th and 6th candle
      if (candle5.open > candle5.close && candle5.close < candle4.close) {
        if (candle6.close < candle5.close) {
          return "red";
        }
      }
      //green candle condition for 5th and 6th candle
      if (candle5.open < candle5.close && candle5.close > candle4.close) {
        if (candle6.close > candle5.close) {
          return "green";
        }
      }
    }
    return "";
  };

  function checkOpenPriceTolerance(candles, tolerance) {
    const firstOpenPrice = candles[0].open;

    return candles.every((candle) => {
      const difference = Math.abs(candle.open - firstOpenPrice);
      const percentageDifference = (difference / firstOpenPrice) * 100;
      return percentageDifference <= tolerance;
    });
  }

  function checkClosePriceTolerance(candles, tolerance) {
    const firstClosePrice = candles[0].close;
    return candles.every((candle) => {
      const difference = Math.abs(candle.close - firstClosePrice);
      const percentageDifference = (difference / firstClosePrice) * 100;
      return percentageDifference <= tolerance;
    });
  }

  return (
    <div>
      <SearchStock getData={fetchDataAndSetData} />
      <table className="candles-table">
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Open</th>
            <th>High</th>
            <th>Low</th>
            <th>Close</th>
          </tr>
        </thead>
        <tbody>
          {data.zomatoCandles.map((candle) => {
            const date = new Date(candle.timestamp);
            const formattedDate = `${date.getFullYear()}-${date.toLocaleString(
              "en-US",
              { month: "long" }
            )}-${date.getDate().toString().padStart(2, "0")} ${date
              .getHours()
              .toString()
              .padStart(2, "0")}:${date
              .getMinutes()
              .toString()
              .padStart(2, "0")}`;

            return (
              <tr
                key={candle.timestamp}
                style={{ backgroundColor: candle.color }}
              >
                <td>{formattedDate}</td>
                <td>Open: {candle.open}</td>
                <td>High: {candle.high}</td>
                <td>Low: {candle.low}</td>
                <td>Close: {candle.close}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default Home;
