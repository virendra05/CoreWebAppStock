import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Navbar from "./Navbar/Navbar";
import Home from "./Home/Home";
import SearchStock from "./SearchStock";
import Zomato from "./Zomato/Zomato";
import "./App.css";

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Zomato" element={<Zomato />} />
          <Route path="/SearchStock" element={<SearchStock />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
